# -*- coding: utf-8 -*-
import numpy as np
import torch
import torch.nn as nn
from torch.autograd import Variable
import torch.nn.functional as F
# import mmd
from sklearn.cluster import KMeans

def NBCEWLoss(input_,od):
    # input_ = input_.cuda()
    input_ = input_
    epsilon = 1e-6
    od = 1 - od
    batch_size = od.size(1) // 2
    # od1 = torch.ones(1, batch_size).cuda()
    od1 = torch.ones(1, batch_size)
    od1 = od1.squeeze(0)
    od2 = od[0,batch_size: od.size(1)]
    od = torch.cat((od1, od2), dim=0)

    od = od.view(-1,1)

    input_ = od* input_
    mask = input_.ge(0.7)  # mask is 0 if elem >= 0.7,
    mask_hw = input_.le(0.2)  # mask is 0 if elem <= 0.2,

    mask_out = torch.masked_select(input_, mask)  #分类概率大的留下，当成伪标签
    mask_out1 = torch.masked_select(input_, mask_hw)  # 分类概率xiao的留下，当成伪标签
    if len(mask_out) and not len(mask_out1):
        entropy = -(torch.sum(mask_out * torch.log(mask_out))) / float(mask_out.size(0))
        return entropy
    elif len(mask_out1) and not len(mask_out):
        entropy1 = -(torch.sum((1-mask_out1) * torch.log(1-mask_out1))) / float(mask_out1.size(0))
        return entropy1
    elif len(mask_out1) and len(mask_out):
        entropy = -(torch.sum(mask_out * torch.log(mask_out))) / float(mask_out.size(0))
        entropy1 = -(torch.sum((1 - mask_out1) * torch.log(1 - mask_out1))) / float(mask_out1.size(0))
        return entropy + entropy1 #1/(number of negative label)* sum((1-mask_out2) * log(1-mask_out2))+1/(number of positive label)* sum((1-mask_out) * log(1-mask_out))
    else:
        # return torch.tensor(0.0).cuda()
        return torch.tensor(0.0)

def grl_hook(coeff):
    def fun1(grad):
        return -coeff*grad.clone()
    return fun1


def DANN(features, ad_net, od):
    ad_out = ad_net(features)
    batch_size = ad_out.size(0) // 2
    # dc_target = torch.from_numpy(np.array([[1]] * batch_size + [[0]] * batch_size)).float().cuda()
    # od = od.float().cuda()
    dc_target = torch.from_numpy(np.array([[1]] * batch_size + [[0]] * batch_size)).float()
    od = od.float()
    od = 1.0 + od
    return nn.BCELoss(weight=od.view(-1))(ad_out.view(-1), dc_target.view(-1))

if __name__=="__main__":
    import numpy as np
    print(np.empty((0,3,3)))
#     a= bin(int('94974F937D4C2433',16))
#     print(a)
#     b = bin(564897)
#     print(b)
#     print(a^b)

