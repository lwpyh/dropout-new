# -*- coding: utf-8 -*-
"""
@Time ： 2021/5/11 9:18
@Auth ： PUCHAZHONG
@File ：mcdropout_utlis.py
@IDE ：PyCharm
@CONTACT: zhonghw@zhejianglab.com
"""
from sklearn.cluster import KMeans
import numpy as np



def get_cls_thresh(delta):  # delta: len(source) * 1
    kmeans = KMeans(n_clusters=2).fit(delta)
    if kmeans.cluster_centers_[0] < kmeans.cluster_centers_[1]:
        thresh = min(delta[np.where(kmeans.labels_ == 1)])
    else:
        thresh = min(delta[np.where(kmeans.labels_ == 0)])
    return thresh[0]
